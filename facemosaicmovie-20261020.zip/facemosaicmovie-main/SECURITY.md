# セキュリティについて

## 脆弱性の報告
見つけた問題は、**公開の Issue には書かず**、GitHub のリポジトリの「Security」タブ →「Report a vulnerability」（Private vulnerability reporting。リポジトリの Settings → Code security で有効にしてください）から非公開で報告してください。
再現手順・影響・ブラウザの種類が分かると助かります。

## このアプリの前提（脅威モデル）
- 動画は利用者の端末の中だけで処理します。**サーバーへ送信しません**（通信は、自分のサイトの静的ファイルの取得のみ）。
- ブラウザの保存領域（localStorage / IndexedDB / Cookie）は使いません。

## 主な対策
| 対象 | 対策 |
|---|---|
| スクリプトの注入（XSS） | CSP（自サイトのファイルのみ許可、インライン・eval・外部サイトは禁止）。HTML を文字列で組み立てず、ファイル名などは `textContent` で表示 |
| 他サイトへの埋め込み（クリックジャッキング） | iframe 内では起動しない（JavaScript）。Apache なら `X-Frame-Options` と `frame-ancestors`（`.htaccess`） |
| モデルの差し替え | モデルの SHA-256 を固定。一致しないものは解析器に渡さない（手動で選んだファイルも同じ） |
| ライブラリ・ファイルの改変/破損 | `integrity.json`（全ファイルの SHA-256）。診断ページで照合。`vendor/VERSIONS.json` で出所を記録 |
| 悪意のあるファイル名 | 制御文字・向きを変える文字（RLO 等）・パス区切り・Windows の予約名を除去してから表示/保存 |
| Worker への不正なメッセージ | 型・範囲・選択肢を検証してから処理（想定外は拒否） |
| 巨大・細工された動画 | 解像度（4K 相当）・容量（4GB）の上限。処理が2分以上止まれば停止して案内 |
| 供給網 | 外部の CDN を使わない（全て同梱）。GitHub Actions は使わない。実行時に依存する外部サービスなし |

## 既知の限界
- GitHub Pages は HTTP ヘッダーを設定できないため、CSP は `<meta>` で指定しています（`frame-ancestors` は meta では効かないので、埋め込み防止は JavaScript で行います）。HTTP ヘッダーを設定できる環境（Apache など）では `.htaccess` を使ってください。
- 同梱ライブラリ（OpenCV.js、Mediabunny）自体の脆弱性は、各プロジェクトの更新に追随する必要があります（`vendor/VERSIONS.json` に版を記載）。
- ブラウザや拡張機能が CSP を無効にしている環境では、一部の保護が働きません（診断ページで検出できます）。
